from __future__ import annotations

import argparse
import ast
import shutil
import subprocess
from pathlib import Path

PROCESS_ROOT = Path('scopes/ada/backend/processes/kpi-runtime')
SOURCE_CATALOG = PROCESS_ROOT / 'src/ada/processes/kpi_runtime/catalog'
COMMENTED_CATALOG = PROCESS_ROOT / 'commented/ada/processes/kpi_runtime/catalog'

REPLACEMENTS = (
    SOURCE_CATALOG / '__init__.py',
    COMMENTED_CATALOG / '__init__.py',
)

ADDITIONS = (
    SOURCE_CATALOG / 'registry.py',
    SOURCE_CATALOG / 'general/__init__.py',
    SOURCE_CATALOG / 'general/specs.py',
    SOURCE_CATALOG / 'general/resolvers.py',
    SOURCE_CATALOG / 'general/logics/__init__.py',
    SOURCE_CATALOG / 'general/over/__init__.py',
    SOURCE_CATALOG / 'general/over/specs.py',
    SOURCE_CATALOG / 'general/over/resolvers.py',
    SOURCE_CATALOG / 'general/over/logics/__init__.py',
    SOURCE_CATALOG / 'mina/__init__.py',
    SOURCE_CATALOG / 'planta/__init__.py',
    SOURCE_CATALOG / 'shared/__init__.py',
    SOURCE_CATALOG / 'shared/logics/__init__.py',
    COMMENTED_CATALOG / 'registry.py',
    COMMENTED_CATALOG / 'general/__init__.py',
    COMMENTED_CATALOG / 'general/specs.py',
    COMMENTED_CATALOG / 'general/resolvers.py',
    COMMENTED_CATALOG / 'general/logics/__init__.py',
    COMMENTED_CATALOG / 'general/over/__init__.py',
    COMMENTED_CATALOG / 'general/over/specs.py',
    COMMENTED_CATALOG / 'general/over/resolvers.py',
    COMMENTED_CATALOG / 'general/over/logics/__init__.py',
    COMMENTED_CATALOG / 'mina/__init__.py',
    COMMENTED_CATALOG / 'planta/__init__.py',
    COMMENTED_CATALOG / 'shared/__init__.py',
    COMMENTED_CATALOG / 'shared/logics/__init__.py',
    PROCESS_ROOT / 'tests/test_catalog_scaffold.py',
)

EXPECTED_PRODUCTIVE_INIT = """from ada.kpis.core import KpiCatalog


def build_catalog() -> KpiCatalog:
    return KpiCatalog(())
"""

EXPECTED_COMMENTED_INIT = """# Espejo pedagógico: el catálogo productivo se mantiene vacío hasta incorporar definiciones KPI explícitas.
from ada.kpis.core import KpiCatalog


def build_catalog() -> KpiCatalog:
    return KpiCatalog(())
"""


def _run(command: list[str], *, cwd: Path) -> None:
    print('>', ' '.join(command), flush=True)
    result = subprocess.run(
        command,
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    print(result.stdout, end='')
    if result.returncode:
        raise subprocess.CalledProcessError(result.returncode, command)


def _require_clean(repo: Path, relative: Path) -> None:
    for command in (
        ['git', 'diff', '--quiet', '--', str(relative)],
        ['git', 'diff', '--cached', '--quiet', '--', str(relative)],
    ):
        result = subprocess.run(command, cwd=repo)
        if result.returncode != 0:
            raise RuntimeError(f'target file has local changes: {relative}')


def _semantic(path: Path) -> str:
    return ast.dump(
        ast.parse(path.read_text(encoding='utf-8'), filename=str(path)),
        include_attributes=False,
    )


def _validate_payload(payload: Path) -> None:
    for relative in (*REPLACEMENTS, *ADDITIONS):
        path = payload / relative
        if not path.is_file():
            raise RuntimeError(f'candidate payload file is missing: {relative}')
        if path.suffix == '.py':
            ast.parse(path.read_text(encoding='utf-8'), filename=str(path))

    productive = payload / SOURCE_CATALOG
    commented = payload / COMMENTED_CATALOG
    productive_files = {
        path.relative_to(productive)
        for path in productive.rglob('*.py')
    }
    commented_files = {
        path.relative_to(commented)
        for path in commented.rglob('*.py')
    }
    if productive_files != commented_files:
        raise RuntimeError('candidate catalog mirror file sets differ')
    for relative in productive_files:
        if _semantic(productive / relative) != _semantic(commented / relative):
            raise RuntimeError(f'candidate commented mirror mismatch: {relative}')


def _validate_baseline(repo: Path) -> None:
    productive = repo / SOURCE_CATALOG / '__init__.py'
    commented = repo / COMMENTED_CATALOG / '__init__.py'

    if productive.read_text(encoding='utf-8') != EXPECTED_PRODUCTIVE_INIT:
        raise RuntimeError('KPI catalog productive baseline changed unexpectedly')
    if commented.read_text(encoding='utf-8') != EXPECTED_COMMENTED_INIT:
        raise RuntimeError('KPI catalog commented baseline changed unexpectedly')


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', required=True)
    args = parser.parse_args()

    repo = Path(args.repo).resolve()
    payload = Path(__file__).resolve().parent / 'payload'

    _validate_payload(payload)
    _validate_baseline(repo)

    for relative in REPLACEMENTS:
        target = repo / relative
        if not target.is_file():
            raise RuntimeError(f'expected baseline file is missing: {relative}')
        _require_clean(repo, relative)

    for relative in ADDITIONS:
        target = repo / relative
        if target.exists():
            raise RuntimeError(f'candidate target already exists: {relative}')

    originals = {
        relative: (repo / relative).read_bytes()
        for relative in REPLACEMENTS
    }
    added: list[Path] = []

    try:
        for relative in REPLACEMENTS:
            shutil.copy2(payload / relative, repo / relative)

        for relative in ADDITIONS:
            target = repo / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(payload / relative, target)
            added.append(target)

        print('R3.6M-005A.4 — installing KPI Catalog Scaffold + Registry 1.0.0')
        _run(
            ['bash', str(repo / 'scripts/scopes/ada/backend/check.sh')],
            cwd=repo,
        )
    except Exception:
        for relative, content in originals.items():
            (repo / relative).write_bytes(content)
        for path in reversed(added):
            if path.exists():
                path.unlink()
        for root in (
            repo / SOURCE_CATALOG,
            repo / COMMENTED_CATALOG,
        ):
            for directory in sorted(
                (path for path in root.rglob('*') if path.is_dir()),
                key=lambda path: len(path.parts),
                reverse=True,
            ):
                try:
                    directory.rmdir()
                except OSError:
                    pass
        print('R3.6M-005A.4 rollback completed.', flush=True)
        raise

    print('R3.6M-005A.4 installed and gate completed successfully.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
