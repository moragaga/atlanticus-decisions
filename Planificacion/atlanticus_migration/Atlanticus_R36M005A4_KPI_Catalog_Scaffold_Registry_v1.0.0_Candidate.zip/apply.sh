#!/usr/bin/env bash
set -euo pipefail
uv run --python 3.14.2 --no-python-downloads --no-project   python "$(dirname "$0")/apply_m005a4.py" "$@"
