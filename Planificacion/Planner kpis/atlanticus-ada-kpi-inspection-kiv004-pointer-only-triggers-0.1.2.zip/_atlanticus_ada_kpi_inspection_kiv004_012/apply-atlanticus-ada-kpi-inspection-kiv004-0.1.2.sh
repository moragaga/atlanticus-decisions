#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-.}"
ROOT="$(cd "$ROOT" && pwd)"
PATCH_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$PATCH_ROOT/payload"
BACKUP="$(mktemp -d "${TMPDIR:-/tmp}/atlanticus-kiv004-pointer.XXXXXX")"
APPLIED=0

cleanup() {
    rm -rf "$BACKUP"
}

backup_project() {
    rel="$1"
    src="$ROOT/$rel"
    dst="$BACKUP/projects/$rel"
    mkdir -p "$dst"
    if [ -d "$src" ]; then
        : > "$dst/.existed"
        for item in pyproject.toml uv.lock .python-version src tests commented; do
            if [ -e "$src/$item" ]; then
                cp -R "$src/$item" "$dst/$item"
            fi
        done
    fi
}

restore_project() {
    rel="$1"
    src="$BACKUP/projects/$rel"
    dst="$ROOT/$rel"
    if [ ! -f "$src/.existed" ]; then
        rm -rf "$dst"
        return
    fi
    mkdir -p "$dst"
    for item in pyproject.toml uv.lock .python-version src tests commented; do
        rm -rf "$dst/$item"
        if [ -e "$src/$item" ]; then
            cp -R "$src/$item" "$dst/$item"
        fi
    done
}

rollback() {
    status=$?
    if [ "$APPLIED" -eq 1 ]; then
        echo 'KIV-004 failed; rolling back Pointer-only Inspection Trigger Calibration'
        restore_project 'scopes/ada/web/ui/global-indicator'
        restore_project 'scopes/ada/web/application/ada-generic-application'
        restore_project 'scopes/ada/web/inspection/interval-resilience'
        restore_project 'scopes/ada/web/inspection/empty-definition-flow'
        restore_project 'scopes/ada/web/inspection/preview'
    fi
    cleanup
    exit "$status"
}

trap rollback ERR INT TERM

if [ ! -f "$ROOT/scripts/scopes/ada/check.sh" ]; then
    echo 'Atlanticus ADA repository root was not found' >&2
    exit 1
fi

require_project() {
    path=$1
    name=$2
    version=$3
    project="$ROOT/$path/pyproject.toml"
    if [ ! -f "$project" ] \
        || ! grep -q "^name = \"$name\"$" "$project" \
        || ! grep -q "^version = \"$version\"$" "$project"; then
        echo "Expected $name $version pre-state" >&2
        exit 1
    fi
}

require_project 'scopes/ada/web/inspection/core' 'ada-web-kpi-inspection-core' '0.2.0'
require_project 'scopes/ada/web/inspection/api' 'ada-web-kpi-inspection-api' '0.1.0'
require_project 'scopes/ada/web/inspection/surface' 'ada-web-kpi-inspection-surface' '0.1.2'
require_project 'scopes/ada/web/inspection/interval-resilience' 'ada-web-kpi-inspection-interval-resilience' '0.1.2'
require_project 'scopes/ada/web/inspection/empty-definition-flow' 'ada-web-kpi-inspection-empty-definition-flow' '0.1.2'
require_project_one_of() {
    path=$1
    name=$2
    shift 2
    project="$ROOT/$path/pyproject.toml"
    if [ ! -f "$project" ] || ! grep -q "^name = \"$name\"$" "$project"; then
        echo "Expected $name pre-state" >&2
        exit 1
    fi
    for version in "$@"; do
        if grep -q "^version = \"$version\"$" "$project"; then
            return 0
        fi
    done
    echo "Expected $name one of: $*" >&2
    exit 1
}

require_project_one_of 'scopes/ada/web/inspection/preview' 'ada-web-kpi-inspection-preview' '0.1.3' '0.1.4'
require_project 'scopes/ada/web/ui/global-indicator' 'ada-web-ui-global-indicator' '0.2.0'
require_project 'scopes/ada/web/application/ada-generic-application' 'ada-generic-application' '0.1.23'

for capability in \
    kpi-inspection-core \
    kpi-inspection-api \
    kpi-inspection-surface \
    kpi-inspection-interval-resilience \
    kpi-inspection-empty-definition-flow \
    global-indicator \
    application \
    kpi-inspection-preview; do
    if ! grep -q "'$capability': AdaCapability(" "$ROOT/scripts/scopes/ada/check.py"; then
        echo "Expected registered ADA capability: $capability" >&2
        exit 1
    fi
done

backup_project 'scopes/ada/web/ui/global-indicator'
backup_project 'scopes/ada/web/application/ada-generic-application'
backup_project 'scopes/ada/web/inspection/interval-resilience'
backup_project 'scopes/ada/web/inspection/empty-definition-flow'
backup_project 'scopes/ada/web/inspection/preview'
APPLIED=1

(
    cd "$PAYLOAD"
    find . -type f -print | while IFS= read -r relative; do
        relative=${relative#./}
        mkdir -p "$ROOT/$(dirname "$relative")"
        cp "$PAYLOAD/$relative" "$ROOT/$relative"
    done
)

printf '%s\n' '[1/3] Locking KIV-004 pointer-only trigger projects'
for rel in \
    scopes/ada/web/ui/global-indicator \
    scopes/ada/web/application/ada-generic-application \
    scopes/ada/web/inspection/interval-resilience \
    scopes/ada/web/inspection/empty-definition-flow \
    scopes/ada/web/inspection/preview; do
    (
        cd "$ROOT/$rel"
        uv lock
    )
done

printf '%s\n' '[2/3] Validating pointer-only KPI Inspection trigger contract'
bash "$ROOT/scripts/scopes/ada/check.sh" \
    kpi-inspection-core \
    kpi-inspection-api \
    kpi-inspection-surface \
    kpi-inspection-interval-resilience \
    kpi-inspection-empty-definition-flow \
    global-indicator \
    application \
    kpi-inspection-preview

printf '%s\n' '[3/3] Confirming KIV-004 pointer-only versions'
require_project 'scopes/ada/web/inspection/surface' 'ada-web-kpi-inspection-surface' '0.1.2'
require_project 'scopes/ada/web/inspection/interval-resilience' 'ada-web-kpi-inspection-interval-resilience' '0.1.3'
require_project 'scopes/ada/web/inspection/empty-definition-flow' 'ada-web-kpi-inspection-empty-definition-flow' '0.1.3'
require_project 'scopes/ada/web/inspection/preview' 'ada-web-kpi-inspection-preview' '0.1.5'
require_project 'scopes/ada/web/ui/global-indicator' 'ada-web-ui-global-indicator' '0.2.1'
require_project 'scopes/ada/web/application/ada-generic-application' 'ada-generic-application' '0.1.24'

trap - ERR INT TERM
cleanup
printf '%s\n' 'KIV-004 corrective 0.1.2 applied successfully'
printf '%s\n' 'Run pointer-only close smoke with:'
printf '%s\n' '  cd scopes/ada/web/inspection/preview && uv run ada-kpi-inspection-preview'
